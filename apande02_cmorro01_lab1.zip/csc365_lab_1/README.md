Ansh Pandey and Cameron Morrow

To interact with the SchoolSearch Program, someone just has to run `python3 schoolseach.py`. It pulls the data from `schoolseach.txt` so to update the data use, that file needs to be updated. 